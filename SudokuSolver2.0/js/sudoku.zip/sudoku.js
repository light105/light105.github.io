function Options(size){
	var arr = [];
	var i;
	var obj = {};

	for(i=0; i<size; i++)
		arr[i] = [];

	obj.getTOS = function(i){
		if(arr[i] == undefined) return undefined;

		return arr[i][arr[i].length-1];
	}

	obj.removeTOS = function(i){
		return arr[i].pop();
	}

	obj.addCandidate = function(i, candidate){
		arr[i].push(candidate);
	}

	return obj;
}



function SudokuSolver(){
	var board=[];
	var solutions = [];
	var subgrid, grid;
	var x, y;
	var tot_b;
	var cur_b;
	var obj = {};

	var cur_num;
	var cand_num;

	var options;

	var backtrack_flag = 0;
	//Object functions
	obj.solve = function(){
		if(board == []){
			return -1;
		}
		cur_b = 0;

		do{
			// console.log("==step==")
			cand_num = 0;
			if(backtrack_flag == 0){
				//console.log(board);
				if(cur_b<tot_b){
					for(var cand=1; cand<=grid; cand++){
						if(isCandidate(cand)){
							options.addCandidate(cur_b, cand);
							cand_num++;
							// console.log("ADDED CANDIDATE: " + cand);
						}
					}
					// console.log(options.getTOS(cur_b));
					if(options.getTOS(cur_b) != undefined){
						board[x[cur_b]][y[cur_b]] = options.getTOS(cur_b);
					}
					if(cand_num == 0){
						backtrack_flag = 1;
					}
					else{
						cur_b++;
					}

				}else if(cur_b == tot_b){ //therefore solution
					var temp = [];

					for(var i=0; i<grid; i++)
						temp.push(board[i].slice());
					
					console.log("----Solution----");
					solutions.push(temp);
					backtrack_flag = 1;
				}
			}else if(backtrack_flag > 0){
				if(backtrack_flag == 1){
					cur_b--;
					board[x[cur_b]][y[cur_b]] = 0;
					options.removeTOS(cur_b);
				}
				if(options.getTOS(cur_b) == undefined){
					cur_b--;
					board[x[cur_b]][y[cur_b]] = 0;
					options.removeTOS(cur_b);
					backtrack_flag = 2;
				}else{
					backtrack_flag = 0;
					board[x[cur_b]][y[cur_b]] = options.getTOS(cur_b);
					cur_b++;
				}
			}

		}while(options.getTOS(0) != undefined);

		console.log("DONE");
	}

	obj.getSolutions = function(){
		return solutions;
	}

	obj.initialize = function(nboard, nsubgrid){
		subgrid = nsubgrid;
		grid = nsubgrid*nsubgrid;

		for(var i=0; i<grid; i++){
			board[i]=[];
			for(var j=0; j<grid; j++)
				board[i][j] = nboard[i][j];
		}

		initializeBlankCoordinates();
		options = Options(tot_b);
	}


	//Class functions
	function initializeBlankCoordinates(){
		tot_b = 0;
		x=[];
		y=[];

		for(var i=0; i<grid; i++){
			for(var j=0; j<grid; j++){
				if(board[i][j]==0){
					x[tot_b] = i;
					y[tot_b] = j;
					tot_b++;
				}
			}
		}
	}

	function isCandidate(num){
		for(var i=0; i<grid; i++){
			var aa = Math.trunc(x[cur_b]/subgrid)*subgrid+Math.trunc(i/subgrid);
			var bb = Math.trunc(y[cur_b]/subgrid)*subgrid+i%subgrid;

			if(board[x[cur_b]][i] == num) return false;
			if(board[i][y[cur_b]] == num) return false;
			if(board[aa][bb] == num) return false;
		}

		return true;
	}

	function isCandidateX(num){
		for(var i=0; i<grid; i++){
			//left leaning: check if x and y coordinate is equal
			if(board[i][i] == num) return false;

			//right leaning: else part
			if(board[i][grid-i-1] == num) return false;
		}

		return true;
	}

	function isCandidateY(num){
		int intersection = (grid%2==0)? (grid/2) : grid+1/2;
		int checker = 0;
		int i = 0, j = 0;
		
		//left side start
		for(i=0; i<intersection; i++){
			if(board[i][i] == num) return false;
		}
		
		for(j=i; j<grid; j++) {
			if(board[i][j] == num) return false;

		}
		//left side end

		//right side start
		for(i=0; i<intersection; i++){
			if(board[grid-i-1][i] == num) return false;
		}
		
		for(j=i; j<grid; j++) {
			if(board[i][j] == num) return false;
		}
		//right side end
		return true;
	}

	return obj;
}